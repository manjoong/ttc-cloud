<?php
/**
 * Deprecated. No longer needed.
 *
 * @package Jetpack
 */
