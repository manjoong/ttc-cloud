woocommerce-product-generator
=============================

A sample product generator for WooCommerce.
